#Create with the name `customer_behavior`. 
CREATE DATABASE IF NOT EXISTS customer_behavior;
 
 
 
#Taking access to the customer_behavior database 
USE customer_behavior;
 
 
 
#Seeing the tables which are present in the database customer_behaviour 
SHOW TABLES;


#Counting the number of records 
SELECT COUNT(*) AS total_records
FROM customer;



#Having an overview 
SELECT *
FROM customer
LIMIT 5;



DESCRIBE customer;





-- Overall Dataset Overview--
SELECT
    COUNT(*) AS total_records,
    COUNT(DISTINCT customer_id) AS unique_customers,
    ROUND(AVG(age), 2) AS average_age,
    MIN(age) AS minimum_age,
    MAX(age) AS maximum_age,
    ROUND(AVG(purchase_amount), 2) AS average_purchase_amount,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(AVG(review_rating), 2) AS average_review_rating
FROM customer;



-- Customer Distribution by Gender
SELECT
    gender,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS percentage
FROM customer
GROUP BY gender
ORDER BY total_customers DESC;



-- Customer Distribution by Product Category

SELECT
    category,
    COUNT(*) AS total_purchases,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS purchase_percentage
FROM customer
GROUP BY category
ORDER BY total_purchases DESC;




-- Purchase Amount Analysis by Product Category
SELECT
    category,
    COUNT(*) AS total_purchases,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(AVG(purchase_amount), 2) AS average_purchase_amount,

    ROUND(
        SUM(purchase_amount) * 100.0 /
        (SELECT SUM(purchase_amount) FROM customer),
        2
    ) AS purchase_amount_percentage

FROM customer

GROUP BY category

ORDER BY total_purchase_amount DESC;





-- Purchase Behaviour Analysis by Age Group

SELECT
    age_group,
    COUNT(*) AS total_customers,
    ROUND(AVG(age), 2) AS average_age,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(AVG(purchase_amount), 2) AS average_purchase_amount,
    ROUND(
        SUM(purchase_amount) * 100.0 /
        (SELECT SUM(purchase_amount) FROM customer),
        2
    ) AS purchase_amount_percentage
FROM customer
GROUP BY age_group
ORDER BY total_purchase_amount DESC;



-- Customer Purchasing Behaviour by Subscription Status

SELECT
    subscription_status,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY subscription_status
ORDER BY total_customers DESC;





-- Customer Purchasing Behaviour by Discount Status
SELECT
    discount_applied,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY discount_applied
ORDER BY total_customers DESC;

 


-- Customer Purchase Frequency Analysis
SELECT
    frequency_of_purchases,
    purchase_frequency_days,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount
FROM customer
GROUP BY
    frequency_of_purchases,
    purchase_frequency_days
ORDER BY purchase_frequency_days ASC;






-- Customer Payment Method Analysis
SELECT
    payment_method,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount
FROM customer
GROUP BY payment_method
ORDER BY total_customers DESC;





-- Customer Shipping Type Analysis

SELECT
    shipping_type,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount
FROM customer
GROUP BY shipping_type
ORDER BY total_customers DESC;





-- Seasonal Purchasing Behaviour Analysis

SELECT
    season,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY season
ORDER BY total_purchase_amount DESC;




-- Location-wise Purchasing Behaviour Analysis

SELECT
    location,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY location
ORDER BY total_purchase_amount DESC
LIMIT 10;






-- Product-wise Performance Analysis

SELECT
    item_purchased,
    COUNT(*) AS total_purchases,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating,
    ROUND(
        SUM(purchase_amount) * 100.0 /
        (SELECT SUM(purchase_amount) FROM customer),
        2
    ) AS purchase_amount_percentage
FROM customer
GROUP BY item_purchased
ORDER BY total_purchase_amount DESC
LIMIT 10;






-- Customer Size Preference Analysis

SELECT
    size,
    COUNT(*) AS total_purchases,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS purchase_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY size
ORDER BY total_purchases DESC;





-- Customer Color Preference Analysis

SELECT
    color,
    COUNT(*) AS total_purchases,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS purchase_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY color
ORDER BY total_purchases DESC;






-- Customer Satisfaction Analysis

SELECT
    CASE
        WHEN review_rating >= 4.5 THEN 'Excellent'
        WHEN review_rating >= 4.0 THEN 'Good'
        WHEN review_rating >= 3.0 THEN 'Average'
        ELSE 'Below Average'
    END AS rating_category,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    ROUND(
        AVG(review_rating), 2
    ) AS average_rating,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    SUM(purchase_amount) AS total_purchase_amount
FROM customer
GROUP BY rating_category
ORDER BY MIN(review_rating) DESC;




-- Customer Segmentation by Age Group and Gender

SELECT
    age_group,
    gender,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating
FROM customer
GROUP BY
    age_group,
    gender
ORDER BY total_purchase_amount DESC;




-- Product Category Preference by Gender
WITH gender_totals AS (
    SELECT
        gender,
        COUNT(*) AS total_customers
    FROM customer
    GROUP BY gender
)

SELECT
    c.gender,
    c.category,
    COUNT(*) AS total_purchases,
    ROUND(
        COUNT(*) * 100.0 / gt.total_customers,
        2
    ) AS category_percentage,
    SUM(c.purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(c.purchase_amount), 2
    ) AS average_purchase_amount,
    ROUND(
        AVG(c.review_rating), 2
    ) AS average_review_rating
FROM customer AS c
JOIN gender_totals AS gt
    ON c.gender = gt.gender
GROUP BY
    c.gender,
    c.category,
    gt.total_customers
ORDER BY
    c.gender,
    total_purchases DESC;
    
    
    
    
-- Top 3 Performing Products within Each Category

WITH product_summary AS (
    SELECT
        category,
        item_purchased,
        COUNT(*) AS total_purchases,
        SUM(purchase_amount) AS total_purchase_amount,
        ROUND(
            AVG(purchase_amount), 2
        ) AS average_purchase_amount,
        ROUND(
            AVG(review_rating), 2
        ) AS average_review_rating
    FROM customer
    GROUP BY
        category,
        item_purchased
),
ranked_products AS (
    SELECT
        *,
        DENSE_RANK() OVER (
            PARTITION BY category
            ORDER BY total_purchase_amount DESC
        ) AS product_rank

    FROM product_summary
)
SELECT
    category,
    product_rank,
    item_purchased,
    total_purchases,
    total_purchase_amount,
    average_purchase_amount,
    average_review_rating
FROM ranked_products
WHERE product_rank <= 3
ORDER BY
    category,
    product_rank; 
    
    
    
    
    
-- verifying
SELECT
    category,
    COUNT(DISTINCT item_purchased) AS total_products
FROM customer
GROUP BY category;





-- Seasonal Purchasing Behaviour by Product Category

WITH seasonal_category_summary AS (
    SELECT
        category,
        season,
        COUNT(*) AS total_purchases,
        SUM(purchase_amount) AS total_purchase_amount,
        ROUND(
            AVG(purchase_amount), 2
        ) AS average_purchase_amount,
        ROUND(
            AVG(review_rating), 2
        ) AS average_review_rating
    FROM customer
    GROUP BY
        category,
        season
)
SELECT
    category,
    season,
    total_purchases,
    ROUND(
        total_purchases * 100.0 /
        SUM(total_purchases) OVER (
            PARTITION BY category
        ),
        2
    ) AS category_purchase_percentage,
    total_purchase_amount,
    average_purchase_amount,
    average_review_rating
FROM seasonal_category_summary
ORDER BY
    category,
    total_purchase_amount DESC;
    
    
 

-- Customer Purchase Value Segmentation
WITH ranked_customers AS (
    SELECT
        customer_id,
        age,
        gender,
        age_group,
        purchase_amount,
        review_rating,
        NTILE(3) OVER (
            ORDER BY purchase_amount DESC, customer_id
        ) AS purchase_tier
    FROM customer
),
customer_segments AS (
    SELECT
        *,
        CASE
            WHEN purchase_tier = 1 THEN 'High'
            WHEN purchase_tier = 2 THEN 'Medium'
            WHEN purchase_tier = 3 THEN 'Low'
        END AS purchase_segment
    FROM ranked_customers
)
SELECT
    purchase_segment,
    COUNT(*) AS total_customers,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM customer),
        2
    ) AS customer_percentage,
    SUM(purchase_amount) AS total_purchase_amount,
    ROUND(
        AVG(purchase_amount), 2
    ) AS average_purchase_amount,
    MIN(purchase_amount) AS minimum_purchase_amount,
    MAX(purchase_amount) AS maximum_purchase_amount,
    ROUND(
        AVG(review_rating), 2
    ) AS average_review_rating,
    ROUND(
        AVG(age), 2
    ) AS average_customer_age
FROM customer_segments
GROUP BY
    purchase_tier,
    purchase_segment
ORDER BY purchase_tier;





-- Subscription and Discount Cross-Analysis

WITH subscription_discount_summary AS (
    SELECT
        subscription_status,
        discount_applied,
        COUNT(*) AS total_customers,
        SUM(purchase_amount) AS total_purchase_amount,
        ROUND(
            AVG(purchase_amount), 2
        ) AS average_purchase_amount,

        ROUND(
            AVG(review_rating), 2
        ) AS average_review_rating
    FROM customer
    GROUP BY
        subscription_status,
        discount_applied
)
SELECT
    subscription_status,
    discount_applied,
    total_customers,
    ROUND(
        total_customers * 100.0 /
        SUM(total_customers) OVER (
            PARTITION BY subscription_status
        ),
        2
    ) AS customer_percentage,
    total_purchase_amount,
    ROUND(
        total_purchase_amount * 100.0 /
        SUM(total_purchase_amount) OVER (
            PARTITION BY subscription_status
        ),
        2
    ) AS purchase_amount_percentage,
    average_purchase_amount,
    average_review_rating
FROM subscription_discount_summary
ORDER BY
    subscription_status,
    discount_applied;
    
    
    
    
    


-- Validate Subscription and Discount Relationship
SELECT
    subscription_status,
    COUNT(*) AS total_customers,
    SUM(
        CASE
            WHEN discount_applied = 'Yes' THEN 1
            ELSE 0
        END
    ) AS customers_with_discount,
    SUM(
        CASE
            WHEN discount_applied = 'No' THEN 1
            ELSE 0
        END
    ) AS customers_without_discount,
    ROUND(
        SUM(
            CASE
                WHEN discount_applied = 'Yes' THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS discount_percentage
FROM customer
GROUP BY subscription_status
ORDER BY subscription_status;    




